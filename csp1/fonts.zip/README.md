Documentation:

Who is the owner?
Me

What is important to the owner?
        -    Showcase the guild and its roster
        -    Interested parties can apply to our guild or contact us
        -    FAQ
        -    Links to our FB/YT page

Who is the audience?
Gamers who play Arena of Valor mobile game

What is important to the audience?
        -    A way to contact the guild/leader/owner (me)
        -    FAQ
        -    Can link to guild’s FB/YT group page


Wireframe:

### For small/mobile

landing/home https://wireframe.cc/CU2ODy

about https://wireframe.cc/6NeOgU

roster https://wireframe.cc/3ftIf2

faq https://wireframe.cc/fipGSr

contact/footer https://wireframe.cc/uRwt3L

### For medium/tablet

roster https://wireframe.cc/pzkDiG

### For large/pc

roster https://wireframe.cc/U8Ra4R
