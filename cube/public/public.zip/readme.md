Documentation:

Who is the owner?
Me

What is important to the owner?
        -    provide a simple yet effective way of helping me in managing my orders.
        -    Orders Page with To-do list per order
        -    Service Level Agreement notifier
        -    Customers page to which any user can comment or add notes info for anyone to see.

Who is the audience?
Project managers, Order Entry, Order Administrators

What is important to the audience?
        -    easy to use
        -    simple/clean UI but full of features
        -    information available for each order entered


Database Schema:
http://dbdesigner.net/designer/schema/159430


Wireframe:
