<?php $__env->startSection('title'); ?>
Customers List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center mb-5">
      <div class="col">
         <div class="form-row">
            <div class="col-2 mb-1">
               <!-- <button class="btn btn-dark createbutton form-control" data-toggle="modal" data-target="#createCustomerModal">Create new Customer</button> -->
               <a class="btn btn-secondary" href='<?php echo e(url("/home")); ?>'>Home</a>
            </div>
            <div class="col-sm-1 col-md-6 col-lg-6 mb-1">
            </div>
            <div class="col">
               <input type="text" class="form-control" id="customerSearch" name="search" placeholder="Search Customers" autocomplete="off">
            </div>
         </div>
      </div>
   </div>
   <div class="row justify-content-center">
      <div class="col">
         <div class="h4 border border-info p-1 rounded" id="customerList">
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button data-index="<?php echo e($customer->id); ?>" class="badge badge-info mb-1 customerbutton" data-toggle="button" aria-pressed="false" autocomplete="off"><?php echo e($customer->name); ?></button>&nbsp;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
      </div>
      <div class="row justify-content-center">
         <div class="col">
            <table class="table table-hover table-sm my-table text-center table-bordered">
               <thead class="thead-dark">
                  <tr>
                     <th style="width: 3%" scope="col"><i class="fas fa-tasks"></i></th>
                     <th scope="col">SO#</th>
                     <th scope="col">Customer Name</th>
                     <th scope="col">PO#</th>
                     <th scope="col">Tags</th>
                     <th style="width: 12%" scope="col">Status</th>
                     <th style="width: 30%" scope="col" class="my-align">Notes</th>
                  </tr>
               </thead>
               <tbody id="customerOrderList">
                  <tr>
                     <td colspan="7">
                        <p class="h4">Select a customer from the list above...</p>
                     </td>
                  </tr>
               </tbody>
            </table>
         </div>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>