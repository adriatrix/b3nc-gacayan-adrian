<?php $__env->startSection('title'); ?>
Tagged List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center mb-5">
      <div class="col">
         <di<div class="d-flex justify-content-between">
            <a class="btn btn-secondary" href='<?php echo e(url("/orders")); ?>'>Back</a>
         </div>
      </div>
   </div>
   <div class="row justify-content-center">
      <div class="col">
         <table class="table table-hover table-sm my-table text-center table-bordered">
            <thead class="thead-dark">
               <tr>
                  <th style="width: 3%" scope="col"><i class="fas fa-tasks"></i></th>
                  <th scope="col">SO#</th>
                  <th scope="col">Customer Name</th>
                  <th scope="col">PO#</th>
                  <th scope="col">Tags</th>
                  <th style="width: 12%" scope="col">Status</th>
                  <th style="width: 30%" scope="col" class="my-align">Notes</th>
               </tr>
            </thead>
            <tbody id="orderList">
               <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($order->get_status->name == 'Cancelled' OR $order->get_status->name == 'Closed'): ?>
               <tr class="text-secondary">
                  <?php else: ?>
                  <tr>
                     <?php endif; ?>
                     <?php if($order->tasks()->where('task_state_id',$tasks_states_id)->count()): ?>
                     <td data-title="Tasks" class="align-middle">
                        <button class="badge badge-pill badge-warning text-hand" disabled><?php echo e($order->tasks()->where('task_state_id',$tasks_states_id)->count()); ?></button>
                     </td>
                     <?php else: ?>
                     <td></td>
                     <?php endif; ?>
                     <td data-title="SO#" class="align-middle"><a href='<?php echo e(url("/orders/$order->id")); ?>'><strong class="text-emerson"><?php echo e($order->so_num); ?></strong></a></td>
                     <td data-title="Customer" class="align-middle"><?php echo e($order->get_customer->name); ?></td>
                     <td data-title="PO#" class="align-middle"><?php echo e($order->po_num); ?></td>
                     <?php if(count($order->tags)): ?>
                     <td data-title="Tags" class="align-middle">
                        <?php $__currentLoopData = $order->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href='<?php echo e(url("/orders/tags/$tag->name")); ?>' class="badge badge-info"><?php echo e($tag->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </td>
                     <?php else: ?>
                     <td></td>
                     <?php endif; ?>
                     <td data-title="Status" class="align-middle"><?php echo e($order->get_status->name); ?></td>
                     <td class="my-align align-middle"><?php echo e($order->notes); ?>

                     </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="editOrderModal<?php echo e($order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="edit Order <?php echo e($order->id); ?>" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                     <div class="modal-header">
                        <h5 class="modal-title" id="editOrder<?php echo e($order->id); ?>">Edit SO# <?php echo e($order->so_num); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <form action="<?php echo e(url("/orders/edit")); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="modal-body">
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Sales Order No.:</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" value="<?php echo e($order->so_num); ?>" name="so_num" required>
                              </div>
                           </div>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Customer Name:</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" value="<?php echo e($order->get_customer->name); ?>" name="customer" required>
                              </div>
                           </div>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Purchase Order No.:</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" value="<?php echo e($order->po_num); ?>" name="po_num" required>
                              </div>
                           </div>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Tags:</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" value="<?php $__currentLoopData = $order->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($tag->name); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" name="tags">
                                 <small class="form-text text-muted">Separate each tags by a space.</small>
                              </div>
                           </div>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Notes:</label>
                              <div class="col-sm-8">
                                 <textarea class="form-control form-control-sm my-align" rows="4" name="notes" id="note"><?php echo e($order->notes); ?></textarea>
                              </div>
                           </div>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Order Status:</label>
                              <div class="col-sm-8">
                                 <select class="form-control" name="status" id="state_change">
                                    <?php $__currentLoopData = $order_states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($order_state->name == $order->get_status->name): ?>
                                    <option value="<?php echo e($order->get_status->name); ?>" selected><?php echo e($order->get_status->name); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($order_state->name); ?>"><?php echo e($order_state->name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                              </div>
                           </div>
                           <hr>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Received Date/Time:</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control form-control-sm" value="<?php echo e($order->received_date); ?>" name="received_date" required>
                              </div>
                           </div>
                           <?php if($order->booked_date): ?>
                             <div class="form-group row">
                               <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Booked Date/Time:</label>
                               <div class="col-sm-8">
                                 <input type="text" class="form-control form-control-sm" value="<?php echo e($order->booked_date); ?>" name="booked_date" required>
                               </div>
                             </div>
                           <?php endif; ?>
                        </div>
                        <div class="modal-footer">
                           <input type="hidden" id="order_id" name="order_id" value="<?php echo e($order->id); ?>">
                           <input class="btn btn-primary" type="submit" name="edit" value="Update">
                        </div>
                     </form>
                  </div>
               </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="modal fade" id="createOrderModal" tabindex="-1" role="dialog" aria-labelledby="create new Order" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                     <div class="modal-header">
                        <h5 class="modal-title" id="createOrder">Create Order</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <form action='<?php echo e(url("/orders/create")); ?>' method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="modal-body">
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Sales Order No.:</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" value="" name="so_num" required>
                              </div>
                           </div>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Customer Name:</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" value="" name="customer" required>
                              </div>
                           </div>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Purchase Order No.:</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" value="" name="po_num" required>
                              </div>
                           </div>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Tags:</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" value="" name="tags">
                                 <small class="form-text text-muted">Separate each tags by a space.</small>
                              </div>
                           </div>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Notes:</label>
                              <div class="col-sm-8">
                                 <textarea class="form-control form-control-sm my-align" name="notes" rows="4"></textarea>
                              </div>
                           </div>
                           <input type="hidden" class="form-control" name="status" value="Received">
                           <hr>
                           <div class="form-group row">
                              <label class="col-sm-4 col-form-label form-control-sm font-weight-bold">Received Date/Time:</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control form-control-sm" value="" name="received_date" required>
                              </div>
                           </div>
                        </div>
                        <div class="modal-footer">
                           <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
                           <input class="btn btn-primary" type="submit" name="create" value="Create">
                        </div>
                     </form>
                  </div>
               </div>
            </div>




         </div>
      </div>
   </div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>