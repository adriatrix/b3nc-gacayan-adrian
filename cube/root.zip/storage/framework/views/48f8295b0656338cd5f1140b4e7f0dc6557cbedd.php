<?php $__env->startSection('title'); ?>
<?php echo e($customer->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center mb-5">
      <div class="col">
         <div class="d-flex justify-content-between">
            <a class="btn btn-secondary" href='<?php echo e(url("/home")); ?>'>Home</a>
            <button class="btn btn-dark" data-toggle="modal" data-target="#createCommentModal">Post</button>
         </div>
      </div>
   </div>
   <div class="row justify-content-center">
      <div class="col">
         <div class="text-center">
           <h1 class="display-5"><span class="border-bottom"><?php echo e($customer->name); ?></span></h1>
         </div>
      </div>
   </div>
   <div class="row justify-content-center">
      <p>&nbsp;</p>
   </div>
   <div class="row justify-content-center">
      <div class="col">
         <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="card border-dark">
            <div class="card-body text-dark" style="white-space: pre-wrap;">
               <h5 class="text-center"><?php echo e($comment->comment); ?></h5>
            </div>
            <div class="card-footer text-right">
               <h6 class="mt-0 mb-1 card-title"><small>contributed by:</small> <strong><?php echo e($comment->get_user->nickname); ?></strong> <small class="text-muted">(<?php echo e($comment->get_user->team); ?>)</small></h6>
               <p class="mt-0 mb-1"><small><?php echo e($comment->updated_at->diffForHumans()); ?></small></p>
            </div>
         </div>
         &nbsp;
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
   </div>
</div>

<div class="modal fade" id="createCommentModal" tabindex="-1" role="dialog" aria-labelledby="add Comment" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="createOrder">Create a comment for <?php echo e($customer->name); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <form action='<?php echo e(url("/comments/create")); ?>' method="post">
            <?php echo e(csrf_field()); ?>

            <div class="modal-body">
               <div class="form-group row">
                  <div class="col">
                     <textarea class="form-control form-control-sm my-align" name="comment" rows="10"></textarea>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <input type="hidden" id="customer_id" name="customer_id" value="<?php echo e($customer->id); ?>">
               <input class="btn btn-primary" type="submit" name="create" value="Create">
            </div>
         </form>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>